<x-guest-layout>
    <div class="prose max-w-none prose-slate">
        {!! $policy !!}
    </div>
</x-guest-layout>
