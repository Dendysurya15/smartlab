<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>SMARTLAB SRS</title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script>
        if (localStorage.getItem('dark-mode') === 'false' || !('dark-mode' in localStorage)) {
                document.querySelector('html').classList.remove('dark');
                document.querySelector('html').style.colorScheme = 'light';
            } else {
                document.querySelector('html').classList.add('dark');
                document.querySelector('html').style.colorScheme = 'dark';
            }
    </script>
</head>

<body class="font-inter antialiased bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400">

    <main class="bg-white">

        <div class="relative flex">


            <!-- Content -->
            <div class="w-full md:w-1/2">

                <div class="min-h-screen h-full flex flex-col after:flex-1">

                    <!-- Header -->
                    <div class="flex-1">
                        <div class="flex items-center justify-center h-16 px-4 sm:px-6 lg:px-8 pt-20">
                            <!-- Logo -->
                            <a class="block" href="<?php echo e(route('dashboard')); ?>">
                                
                                <div class="">
                                    <img class="" src="<?php echo e(asset('images/LOGO-SRS.png')); ?>" width="170" height="170"
                                        alt="Alex Shatov" />
                                </div>
                            </a>
                            
                        </div>
                    </div>

                    <div class="w-full max-w-sm mx-auto px-4 py-8">
                        <h1 class="text-3xl text-slate-800 dark:text-slate-100 font-bold mb-6"><?php echo e(__('Track Progress
                            Sampel')); ?></h1>
                        <h1 class="italic mb-4">Masukkan kode unik sistem untuk melacak progress sampel anda !
                            
                        </h1>
                        <form method="POST" action="<?php echo e(route('register')); ?>" id="tracking-form">
                            <?php echo csrf_field(); ?>
                            <div class="space-y-4">
                                <div>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'jetstream::components.label','data' => ['for' => 'kode']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'kode']); ?><?php echo e(__('Kode')); ?> <span class="text-rose-500">*</span>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'jetstream::components.input','data' => ['id' => 'kode','type' => 'text','name' => 'kode','value' => old('kode'),'required' => true,'autofocus' => true,'autocomplete' => 'kode']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'kode','type' => 'text','name' => 'kode','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('kode')),'required' => true,'autofocus' => true,'autocomplete' => 'kode']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                            </div>
                            <div class="flex items-center mt-6">

                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'jetstream::components.button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                    <?php echo e(__('Submit')); ?>



                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <svg aria-hidden="true" id="loading" style="display: none"
                                    class="ml-3 inline w-5 h-5 mr-2 text-gray-200 animate-spin dark:text-gray-600 fill-gray-600"
                                    viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                                        fill="currentColor" />
                                    <path
                                        d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                                        fill="currentFill" />
                                </svg>
                            </div>

                        </form>


                        <div class="mt-5" id="result" style="display: none">
                            <div
                                class="max-w-sm p-6 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                                
                                    <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white"
                                        id="kode_track_hasil">
                                    </h5>
                                    
                                
                                <ul id="progress-list" class="space-y-4 text-left text-gray-500 dark:text-gray-400">

                                </ul>
                            </div>
                        </div>

                        <div class="mt-5 mb-2 text-sm text-slate-600 font-medium italic" id="result_empty"
                            style="display: none">Tidak menemukan sampel dengan kode <span id="kode_track_failed"
                                class="text-red-600"></span>

                        </div>
                    </div>

                </div>

            </div>

            <!-- Image -->
            <div class="hidden md:block absolute top-0 bottom-0 right-0 md:w-1/2" aria-hidden="true">
                <img class="object-cover object-center w-full h-full" src="<?php echo e(asset('images/YCH09564.jpg')); ?>"
                    width="760" height="1024" alt="Authentication image" />
                
            </div>
        </div>

    </main>
</body>

</html>

<script>
    document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('tracking-form');
    const resultElement = document.getElementById('result');
    const resultEmptyElement = document.getElementById('result_empty');
    const kode_track_hasil = document.getElementById('kode_track_hasil');
    const kode_track_failed = document.getElementById('kode_track_failed');
    const ulElement = document.getElementById('progress-list');
    const loadingSpinner = document.getElementById('loading');
    form.addEventListener('submit', function (e) {
        e.preventDefault();

        const kode = document.getElementById('kode').value;
        loadingSpinner.style.display = 'block';
        // Make an AJAX request
        const xhr = new XMLHttpRequest();
        xhr.open('POST', '<?php echo e(route('search_sampel_progress')); ?>', true);
        xhr.setRequestHeader('X-CSRF-TOKEN', '<?php echo e(csrf_token()); ?>');
        xhr.setRequestHeader('Content-Type', 'application/json;charset=UTF-8');
        
        xhr.onerror = function() {
            console.error('Network request failed');
            loadingSpinner.style.display = 'none';
        };

        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                loadingSpinner.style.display = 'none';
                ulElement.innerHTML = '';
                if (xhr.status === 200) {
                    
                        const response = JSON.parse(xhr.responseText);

                        if (response && Object.keys(response).length > 0) {
                            resultEmptyElement.style.display = 'none';
                            resultElement.style.display = 'block';
                            
                            if (!ulElement) {
                                // If the ul element doesn't exist, create it
                                ulElement = document.createElement('ul');
                                ulElement.id = 'progress-list';
                                ulElement.classList.add('space-y-4', 'text-left', 'text-gray-500', 'dark:text-gray-400');

                                // Append the newly created ul to the resultElement
                                resultElement.appendChild(ulElement);
                            }
                            
                            kode_track_hasil.textContent = response.kode_track;
                            var arr_progress = response.progress;
                            var arr_last_update = response.last_update;
                            
                            var inc = 0
                            arr_progress.forEach(element => {
                                const li = document.createElement('li');
                                li.classList.add('flex', 'items-start', 'space-x-3');

                                const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
                                svg.classList.add('mt-1', 'w-4.5', 'h-3.5', 'text-green-500', 'dark:text-green-400');
                                svg.setAttribute('aria-hidden', 'true');
                                svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
                                svg.setAttribute('fill', 'none');
                                svg.setAttribute('viewBox', '0 0 16 12');

                                const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                                path.setAttribute('stroke', 'currentColor');
                                path.setAttribute('stroke-linecap', 'round');
                                path.setAttribute('stroke-linejoin', 'round');
                                path.setAttribute('stroke-width', '2');
                                path.setAttribute('d', 'M1 5.917 5.724 10.5 15 1.5');
                                svg.appendChild(path);

                                const div = document.createElement('div');
                                const p = document.createElement('p');
                                p.classList.add('mb-0', 'text-sm', 'text-slate-800', 'font-semibold');
                                p.textContent = element;
                                const p2 = document.createElement('p');
                                p2.classList.add('mb-2', 'text-sm', 'text-slate-600', 'font-medium', 'italic');
                                p2.textContent = arr_last_update[inc];

                                // Append the SVG and text content to the li element
                                div.appendChild(p);
                                div.appendChild(p2);
                                li.appendChild(svg);
                                li.appendChild(div);

                                // Append the li element to the ul
                                ulElement.appendChild(li);
                                inc++
                            });
                        } else {
                            resultElement.style.display = 'none';
                            resultEmptyElement.style.display = 'block';
                            // console.log('Empty response received.');
                            kode_track_failed.textContent =  kode ;
                        }
                    
                }
                // Handle other HTTP status codes here if necessary
            }
        };

        const data = JSON.stringify({ kode: kode });
        xhr.send(data);
    });
});

</script><?php /**PATH C:\laragon\www\ssms-smartlab\resources\views/pages/trackingSampel/index.blade.php ENDPATH**/ ?>