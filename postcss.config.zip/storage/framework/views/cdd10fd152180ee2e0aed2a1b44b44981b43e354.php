<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn bg-emerald-500 hover:bg-emerald-600 text-white
    whitespace-nowrap'])); ?>>
    <?php echo e($slot); ?>

</button><?php /**PATH C:\laragon\www\ssms-smartlab\resources\views/vendor/jetstream/components/button.blade.php ENDPATH**/ ?>