<?php return array (
  'history-sampel-tabel' => 'App\\Http\\Livewire\\HistorySampelTabel',
);